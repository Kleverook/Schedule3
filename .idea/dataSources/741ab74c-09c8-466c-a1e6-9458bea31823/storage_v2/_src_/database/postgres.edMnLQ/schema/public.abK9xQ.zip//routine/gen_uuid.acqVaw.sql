create function gen_uuid() returns text
    language plpgsql
as
$$
BEGIN
	return (SELECT uuid_in(overlay(overlay(md5(random()::text || ':' || clock_timestamp()::text) placing '4' from 13) placing to_hex(floor(random()*(11-8+1) + 8)::int)::text from 17)::cstring));
	END;
$$;

alter function gen_uuid() owner to postgres;

